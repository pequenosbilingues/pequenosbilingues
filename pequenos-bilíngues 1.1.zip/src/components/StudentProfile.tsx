/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Student, ClassSession, MonthlyPayment, StudentContract } from '../types';
import { 
  ArrowLeft, Calendar, FileText, DollarSign, Award, 
  MapPin, Phone, MessageSquare, Mail, Clipboard, ChevronRight, 
  Plus, Upload, Trash2, Check, Download, AlertCircle, Edit2, Smile
} from 'lucide-react';

interface StudentProfileProps {
  student: Student;
  classes: ClassSession[];
  payments: MonthlyPayment[];
  contracts: StudentContract[];
  onBack: () => void;
  onAddClass: (classSession: Omit<ClassSession, 'id'>) => void;
  onUpdatePaymentStatus: (paymentId: string, status: 'Pago' | 'Pendente' | 'Atrasado') => void;
  onAddContract: (studentId: string, fileName: string, fileSize: string) => void;
  onDeleteContract: (contractId: string) => void;
}

export default function StudentProfile({
  student,
  classes,
  payments,
  contracts,
  onBack,
  onAddClass,
  onUpdatePaymentStatus,
  onAddContract,
  onDeleteContract
}: StudentProfileProps) {
  
  // Current Tab selection
  const [activeTab, setActiveTab] = useState<'pedagogico' | 'financeiro' | 'contratos'>('pedagogico');

  // New Class Form State (directly in pedagogical tab for convenience)
  const [newClassData, setNewClassData] = useState({
    date: new Date('2026-06-08').toISOString().split('T')[0],
    time: '14:00',
    theme: '',
    vocabulary: '',
    notes: '',
    status: 'Concluída' as const,
    participation: 'Excelente' as const,
    professor: 'Teacher Carla'
  });
  const [classFormSuccess, setClassFormSuccess] = useState(false);

  // File Upload drag status
  const [dragActive, setDragActive] = useState(false);

  // Filter classes & payments for this student
  const studentClasses = classes
    .filter(c => c.studentId === student.id)
    .sort((a, b) => b.date.localeCompare(a.date)); // newest first

  const studentPayments = payments
    .filter(p => p.studentId === student.id)
    .sort((a, b) => b.dueDate.localeCompare(a.dueDate));

  const studentContracts = contracts.filter(c => c.studentId === student.id);

  // Calculate age representatively for year 2026
  const calculateAge = (birthDateStr: string) => {
    if (!birthDateStr) return '';
    const birthDate = new Date(birthDateStr);
    const currentDate = new Date('2026-06-08');
    let age = currentDate.getFullYear() - birthDate.getFullYear();
    const m = currentDate.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && currentDate.getDate() < birthDate.getDate())) {
      age--;
    }
    return age <= 0 ? 'Menos de 1 ano' : `${age} anos`;
  };

  const handleClassSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClassData.theme) return;

    onAddClass({
      studentId: student.id,
      studentName: student.name,
      ...newClassData
    });

    setClassFormSuccess(true);
    setNewClassData({
      date: new Date('2026-06-08').toISOString().split('T')[0],
      time: '14:00',
      theme: '',
      vocabulary: '',
      notes: '',
      status: 'Concluída',
      participation: 'Excelente',
      professor: 'Teacher Carla'
    });

    setTimeout(() => {
      setClassFormSuccess(false);
    }, 4000);
  };

  // Drag and drop events for Contracts upload
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.name.toLowerCase().endsWith('.pdf')) {
        const sizeInMb = (file.size / (1024 * 1024)).toFixed(1);
        onAddContract(student.id, file.name, `${sizeInMb} MB`);
      } else {
        alert("Apenas arquivos no formato PDF são permitidos!");
      }
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.name.toLowerCase().endsWith('.pdf')) {
        const sizeInMb = (file.size / (1024 * 1024)).toFixed(1);
        onAddContract(student.id, file.name, `${sizeInMb} MB`);
      } else {
        alert("Apenas arquivos no formato PDF são permitidos!");
      }
    }
  };

  const handleSimulateUpload = () => {
    // Simulated upload trigger from click
    const mockNames = [
      'contrato_prestacao_servicos_assinado.pdf',
      'termo_autorizacao_imagem_ludica.pdf',
      'atestado_vacina_infantil.pdf',
      'ficha_anamnese_pedagogica_inicial.pdf'
    ];
    const rndName = mockNames[Math.floor(Math.random() * mockNames.length)];
    const rndSize = `${(Math.random() * 1.5 + 0.3).toFixed(1)} MB`;
    
    onAddContract(student.id, rndName, rndSize);
  };

  return (
    <div className="space-y-6 animate-fade-in text-marinho">
      
      {/* Back button link */}
      <button 
        onClick={onBack}
        className="flex items-center gap-1.5 text-xs font-bold text-marinho/60 hover:text-marinho cursor-pointer focus:outline-none"
      >
        <ArrowLeft size={16} /> Voltar para Nossos Pequenos
      </button>

      {/* Main information header block (Scrapbook feel card) */}
      <div className="bg-white p-6 rounded-scrapbook shadow-sm border-2 border-areia-dark/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-menta/15 organic-blob-1 -z-10" />

        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-6">
          
          <div className="flex flex-col sm:flex-row items-center gap-5">
            {/* Avatar block */}
            <div className="w-16 h-16 rounded-full bg-menta flex items-center justify-center font-display font-black text-2xl text-marinho">
              {student.name.charAt(0)}
            </div>

            <div className="text-center sm:text-left space-y-1">
              <div className="flex flex-col sm:flex-row items-center gap-2">
                <h1 className="font-display font-black text-2xl text-marinho">{student.name}</h1>
                <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                  student.status === 'Ativo' ? 'bg-emerald-100 text-emerald-800' :
                  student.status === 'Pausado' ? 'bg-amber-100 text-amber-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {student.status}
                </span>
              </div>

              <div className="text-xs text-marinho/60 font-semibold flex flex-wrap justify-center sm:justify-start gap-x-4 gap-y-1">
                <span>🎂 {student.birthDate.split('-').reverse().join('/')} ({calculateAge(student.birthDate)})</span>
                <span>📅 Matriculado em {student.enrollmentDate.split('-').reverse().join('/')}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-6 pt-4 md:pt-0 border-t md:border-t-0 border-marinho/5 md:pl-6 text-center">
            <div>
              <span className="block text-[10px] text-marinho/45 font-bold uppercase">Modalidade</span>
              <span className="block font-display font-bold text-sm text-marinho mt-1">{student.modality}</span>
            </div>
            <div>
              <span className="block text-[10px] text-marinho/45 font-bold uppercase">Freq Semanal</span>
              <span className="block font-display font-bold text-sm text-marinho mt-1">{student.frequency} aula(s)</span>
            </div>
            <div>
              <span className="block text-[10px] text-marinho/45 font-bold uppercase">Mensalidade</span>
              <span className="block font-display font-display font-bold text-sm text-marinho mt-1 font-mono">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(student.monthlyFee)}
              </span>
            </div>
          </div>

        </div>

        {/* Contact/Address Quick row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6 pt-6 border-t border-marinho/5 text-xs text-marinho/80">
          <div className="flex items-center gap-2">
            <span className="font-bold text-marinho">Responsável:</span> {student.parentName}
          </div>
          <div className="flex items-center gap-2">
            <Phone size={12} className="text-marinho/40 shrink-0" />
            <span>{student.phone}</span>
          </div>
          <div className="flex items-center gap-2">
            <MessageSquare size={12} className="text-marinho/40 shrink-0" />
            <a 
              href={`https://wa.me/${student.whatsapp}`} 
              target="_blank" 
              rel="noreferrer"
              className="text-coral hover:underline font-bold"
            >
              Envio WhatsApp
            </a>
          </div>
          <div className="flex items-center gap-2 sm:col-span-2 lg:col-span-1">
            <MapPin size={12} className="text-marinho/40 shrink-0" />
            <span className="truncate" title={student.address}>{student.address || 'Endereço não cadastrado'}</span>
          </div>
        </div>

        {student.observations && (
          <div className="mt-4 p-3 bg-areia/45 border border-marinho/5 rounded-xl text-xs leading-relaxed text-marinho/80">
            <strong>Observações Pedagógicas Iniciais:</strong> {student.observations}
          </div>
        )}

      </div>

      {/* Tabs navigation */}
      <div className="flex border-b border-areia-dark/15">
        <button
          onClick={() => setActiveTab('pedagogico')}
          className={`px-5 py-3 text-xs font-bold uppercase tracking-wide border-b-2 transition-all cursor-pointer ${
            activeTab === 'pedagogico' 
              ? 'border-coral text-marinho' 
              : 'border-transparent text-marinho/50 hover:text-marinho'
          }`}
        >
          📝 Histórico Pedagógico & Registro
        </button>
        <button
          onClick={() => setActiveTab('financeiro')}
          className={`px-5 py-3 text-xs font-bold uppercase tracking-wide border-b-2 transition-all cursor-pointer ${
            activeTab === 'financeiro' 
              ? 'border-coral text-marinho' 
              : 'border-transparent text-marinho/50 hover:text-marinho'
          }`}
        >
          💵 Financeiro / Mensalidades
        </button>
        <button
          onClick={() => setActiveTab('contratos')}
          className={`px-5 py-3 text-xs font-bold uppercase tracking-wide border-b-2 transition-all cursor-pointer ${
            activeTab === 'contratos' 
              ? 'border-coral text-marinho' 
              : 'border-transparent text-marinho/50 hover:text-marinho'
          }`}
        >
          📂 Contrato Anexo ({studentContracts.length})
        </button>
      </div>

      {/* TAB CONTENT: PEDAGÓGICO */}
      {activeTab === 'pedagogico' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* List of past logged classes */}
          <div className="lg:col-span-7 space-y-4">
            <h3 className="font-display font-bold text-lg text-marinho px-1">Diário e Histórico de Aulas</h3>

            {studentClasses.length === 0 ? (
              <div className="bg-white p-8 rounded-scrapbook border border-dashed border-marinho/10 text-center text-marinho/50">
                Outra aula ainda não realizada ou registrada para esse aluno. Comece preenchendo o formulário ao lado!
              </div>
            ) : (
              <div className="space-y-4">
                {studentClasses.map((cl) => (
                  <div key={cl.id} className="bg-white p-5 rounded-scrapbook shadow-xs border border-areia-dark/15 space-y-3">
                    
                    {/* Class header segment */}
                    <div className="flex justify-between items-start">
                      <div className="space-y-0.5">
                        <span className="text-[10px] font-bold text-marinho/40 block">AULA EM {cl.date.split('-').reverse().join('/')} às {cl.time}</span>
                        <h4 className="font-display font-medium text-lg text-marinho">{cl.theme}</h4>
                      </div>

                      <div className="flex gap-1.5 items-center">
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                          cl.status === 'Concluída' ? 'bg-emerald-100 text-emerald-800' : 
                          cl.status === 'Agendada' ? 'bg-blue-100 text-blue-800' :
                          cl.status === 'Reposição' ? 'bg-coral/20 text-marinho' : 'bg-red-100 text-red-800'
                        }`}>
                          {cl.status}
                        </span>
                        
                        {cl.participation && (
                          <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold bg-[#A8D5C2]/20 text-marinho`}>
                            ⭐ {cl.participation}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Vocab learn segment */}
                    {cl.vocabulary && (
                      <div className="text-xs bg-areia/40 p-2.5 rounded-xl border border-areia-dark/5">
                        <span className="font-bold text-[10px] text-marinho/50 uppercase block mb-0.5">Vocabulário Aprendido</span>
                        <p className="font-medium">{cl.vocabulary}</p>
                      </div>
                    )}

                    {/* Pedagogical notes segment */}
                    {cl.notes && (
                      <div className="text-xs space-y-1 pl-1">
                        <span className="font-bold text-[10px] text-[#B5A1C9] uppercase block">Acompanhamento e Participação</span>
                        <p className="text-marinho/80 leading-relaxed italic">"{cl.notes}"</p>
                      </div>
                    )}

                    {/* Professor name bottom */}
                    {cl.professor && (
                      <div className="text-[9px] text-marinho/40 font-bold uppercase pt-2 border-t border-marinho/5">
                        Registrado por: {cl.professor}
                      </div>
                    )}

                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Form to log single class session directly */}
          <div className="lg:col-span-5 bg-white p-6 rounded-scrapbook border-2 border-amarelo/30 space-y-4">
            <h3 className="font-display font-bold text-base text-marinho flex items-center gap-2">
              📝 Registrar Nova Aula Realizada
            </h3>

            {classFormSuccess && (
              <div className="bg-menta/25 border border-menta text-marinho p-3.5 rounded-xl text-xs text-center font-semibold animate-pulse">
                Aula registrada com sucesso na ficha do pequeno! 🎉
              </div>
            )}

            <form onSubmit={handleClassSubmit} className="space-y-4">
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-marinho/60 mb-1 uppercase">Data da Aula</label>
                  <input 
                    type="date"
                    required
                    value={newClassData.date}
                    onChange={(e) => setNewClassData(prev => ({ ...prev, date: e.target.value }))}
                    className="w-full bg-areia/40 border border-marinho/10 p-2 rounded-xl text-xs font-semibold outline-none focus:border-coral"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-marinho/60 mb-1 uppercase">Horário</label>
                  <input 
                    type="time"
                    required
                    value={newClassData.time}
                    onChange={(e) => setNewClassData(prev => ({ ...prev, time: e.target.value }))}
                    className="w-full bg-areia/40 border border-marinho/10 p-2 rounded-xl text-xs font-semibold outline-none focus:border-coral"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-marinho/60 mb-1 uppercase">Tema da Aula</label>
                <input 
                  type="text"
                  required
                  placeholder="Ex: Farm Animals, Colors and Shapes"
                  value={newClassData.theme}
                  onChange={(e) => setNewClassData(prev => ({ ...prev, theme: e.target.value }))}
                  className="w-full bg-areia/40 border border-marinho/10 p-2.5 rounded-xl text-xs outline-none focus:border-coral"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-marinho/60 mb-1 uppercase">Vocabulário Praticado</label>
                <input 
                  type="text"
                  required
                  placeholder="Ex: Cow, Pig, Sheep, Horse"
                  value={newClassData.vocabulary}
                  onChange={(e) => setNewClassData(prev => ({ ...prev, vocabulary: e.target.value }))}
                  className="w-full bg-areia/40 border border-marinho/10 p-2.5 rounded-xl text-xs outline-none focus:border-coral"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-marinho/60 mb-1 uppercase">Participação</label>
                  <select
                    value={newClassData.participation}
                    onChange={(e) => setNewClassData(prev => ({ ...prev, participation: e.target.value as any }))}
                    className="w-full bg-areia/40 border border-marinho/10 p-2 rounded-xl text-[11px] outline-none focus:border-coral"
                  >
                    <option value="Excelente">Excelente (Super ativa)</option>
                    <option value="Boa">Boa (Interessada)</option>
                    <option value="Em desenvolvimento">Em desenvolvimento (Tímida/Em progresso)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-marinho/60 mb-1 uppercase">Status</label>
                  <select
                    value={newClassData.status}
                    onChange={(e) => setNewClassData(prev => ({ ...prev, status: e.target.value as any }))}
                    className="w-full bg-areia/40 border border-marinho/10 p-2 rounded-xl text-[11px] outline-none focus:border-coral"
                  >
                    <option value="Concluída">Concluída</option>
                    <option value="Reposição">Reposição</option>
                    <option value="Cancelada">Cancelada</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-marinho/60 mb-1 uppercase">Observações Pedagógicas (Diário)</label>
                <textarea 
                  required
                  placeholder="Ex: Arthur imitou os barulhos dos animais muito alegremente..."
                  value={newClassData.notes}
                  onChange={(e) => setNewClassData(prev => ({ ...prev, notes: e.target.value }))}
                  className="w-full bg-areia/40 border border-marinho/10 p-3 rounded-xl text-xs outline-none focus:border-coral h-24 resize-none"
                />
              </div>

              <button 
                type="submit"
                className="w-full bg-marinho hover:bg-marinho/90 text-white font-bold py-3 rounded-xl shadow-xs hover:shadow-md transition-all text-sm cursor-pointer"
              >
                Salvar Registro na Ficha
              </button>

            </form>
          </div>

        </div>
      )}

      {/* TAB CONTENT: FINANCEIRO */}
      {activeTab === 'financeiro' && (
        <div className="bg-white p-6 rounded-scrapbook border-2 border-areia shadow-xs space-y-6">
          <div className="flex justify-between items-center pl-1">
            <h3 className="font-display font-bold text-lg text-marinho">Controle de Mensalidades do Aluno</h3>
            <span className="text-xs text-marinho/50">Cobranças associadas à data de matrícula</span>
          </div>

          {studentPayments.length === 0 ? (
            <div className="p-8 text-center text-marinho/50">
              Nenhuma mensalidade gerada para esse aluno até o momento.
            </div>
          ) : (
            <div className="space-y-4">
              {studentPayments.map((pay) => (
                <div 
                  key={pay.id} 
                  className={`p-4 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 border ${
                    pay.status === 'Pago' ? 'bg-emerald-50/50 border-emerald-100' :
                    pay.status === 'Atrasado' ? 'bg-red-50/50 border-red-100' : 'bg-amber-50/50 border-amber-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-3 h-10 rounded-full ${
                      pay.status === 'Pago' ? 'bg-emerald-400' :
                      pay.status === 'Atrasado' ? 'bg-red-400' : 'bg-amber-300'
                    }`} />
                    
                    <div>
                      <p className="text-xs text-marinho/60 font-bold uppercase">MENSALIDADE</p>
                      <h4 className="font-display font-medium text-base text-marinho">
                        Referência: {pay.dueDate.split('-')[1]}/{pay.dueDate.split('-')[0]}
                      </h4>
                      <p className="text-[10px] text-marinho/50 font-bold">
                        Vencimento: {pay.dueDate.split('-').reverse().join('/')} 
                        {pay.paymentDate && ` | Pago em: ${pay.paymentDate.split('-').reverse().join('/')}`}
                      </p>
                    </div>
                  </div>

                  <div className="flex sm:flex-col items-end justify-between sm:justify-start gap-4 sm:gap-2">
                    <span className="font-display font-bold text-lg text-marinho font-mono">
                      {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(pay.amount)}
                    </span>

                    {/* Quick status cycle button */}
                    <div className="flex gap-2">
                      <button 
                        onClick={() => onUpdatePaymentStatus(pay.id, 'Pago')}
                        className={`text-[10px] uppercase font-bold px-2 py-1 rounded-md transition-all cursor-pointer ${
                          pay.status === 'Pago' ? 'bg-emerald-500 text-white' : 'bg-white border border-marinho/10 text-marinho hover:bg-emerald-50'
                        }`}
                      >
                        Pago
                      </button>
                      <button 
                        onClick={() => onUpdatePaymentStatus(pay.id, 'Pendente')}
                        className={`text-[10px] uppercase font-bold px-2 py-1 rounded-md transition-all cursor-pointer ${
                          pay.status === 'Pendente' ? 'bg-amber-400 text-white' : 'bg-white border border-marinho/10 text-marinho hover:bg-amber-50'
                        }`}
                      >
                        Pendente
                      </button>
                      <button 
                        onClick={() => onUpdatePaymentStatus(pay.id, 'Atrasado')}
                        className={`text-[10px] uppercase font-bold px-2 py-1 rounded-md transition-all cursor-pointer ${
                          pay.status === 'Atrasado' ? 'bg-red-500 text-white' : 'bg-white border border-marinho/10 text-marinho hover:bg-red-50'
                        }`}
                      >
                        Atrasado
                      </button>
                    </div>
                  </div>

                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: CONTRATOS */}
      {activeTab === 'contratos' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Contracts List */}
          <div className="lg:col-span-7 bg-white p-6 rounded-scrapbook border-2 border-areia shadow-xs space-y-4">
            <h3 className="font-display font-bold text-lg text-marinho">Contratos de Prestação de Serviços</h3>

            {studentContracts.length === 0 ? (
              <div className="p-8 text-center text-marinho/50 space-y-2 border border-dashed border-marinho/10 rounded-xl">
                <p className="text-sm">Nenhum contrato assinado foi anexado a este aluno ainda.</p>
                <p className="text-xs">Arraste um PDF ou use o simulador para preencher a documentação contratual oficial.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {studentContracts.map((cnt) => (
                  <div key={cnt.id} className="flex items-center justify-between p-4 bg-areia/35 border border-areia-dark/10 rounded-2xl">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-coral/20 text-marinho rounded-xl">
                        <FileText size={20} />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-marinho truncate max-w-[200px] sm:max-w-[300px]" title={cnt.fileName}>
                          {cnt.fileName}
                        </p>
                        <p className="text-[10px] text-marinho/50 font-bold">
                          Tamanho: {cnt.fileSize} | Anexado em: {cnt.uploadedAt.split('-').reverse().join('/')}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <a 
                        href="#" 
                        onClick={(e) => { e.preventDefault(); alert("Simulando download do arquivo PDF assinado em alta definição...") }}
                        title="Fazer Download"
                        className="p-1.5 bg-white border border-marinho/10 text-marinho/70 hover:text-marinho rounded-lg hover:shadow-xs transition"
                      >
                        <Download size={14} />
                      </a>
                      <button 
                        onClick={() => onDeleteContract(cnt.id)}
                        title="Deletar Contrato"
                        className="p-1.5 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Interactive Simulated File Uploader */}
          <div className="lg:col-span-5 bg-white p-6 rounded-scrapbook border-2 border-dashed border-marinho/15 text-center">
            
            <h4 className="font-display font-bold text-marinho mb-2">Upload de Contrato PDF</h4>
            <p className="text-xs text-marinho/60 mb-6 font-medium">Insira o termo anual assinado ou fotos de autorização</p>
            
            {/* Action Box */}
            <div 
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              onClick={handleSimulateUpload}
              className={`p-8 border-2 border-dashed rounded-2xl cursor-pointer transition-all flex flex-col items-center justify-center space-y-3 group ${
                dragActive 
                  ? 'border-coral bg-coral/5 scale-[1.01]' 
                  : 'border-areia-dark/20 hover:border-coral bg-areia/25 hover:bg-coral/5'
              }`}
            >
              <div className="p-3 bg-white rounded-full text-marinho shadow-xs group-hover:scale-110 transition-transform">
                <Upload size={24} className="text-coral" />
              </div>
              
              <div className="space-y-1">
                <p className="text-xs font-bold text-marinho">Arraste o contrato PDF aqui</p>
                <p className="text-[10px] text-marinho/50">Ou clique para simular upload rápido automático</p>
              </div>

              {/* Hidden system files uploader */}
              <input 
                type="file" 
                accept="application/pdf"
                onChange={handleFileInputChange}
                className="hidden" 
                id="student-contract-real-upload" 
              />
              <label 
                htmlFor="student-contract-real-upload"
                onClick={(e) => e.stopPropagation()}
                className="cursor-pointer bg-white px-4 py-1.5 rounded-full border border-marinho/15 font-bold text-[10px] text-marinho hover:bg-marinho hover:text-white transition inline-block shadow-xs"
              >
                Selecionar PDF local
              </label>
            </div>

            <div className="flex items-start gap-2 text-left mt-4 p-2.5 bg-amarelo/10 border border-amarelo/30 rounded-xl text-[10px] text-marinho/70">
              <AlertCircle size={14} className="shrink-0 mt-0.5" />
              <span>O sistema arquiva os contratos diretamente sob a ID do aluno de maneira durável, permitindo o download em qualquer dispositivo móvel.</span>
            </div>

          </div>

        </div>
      )}

    </div>
  );
}
