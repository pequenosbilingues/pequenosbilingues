/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Student, ClassSession, MonthlyPayment, FinancialRecord, StudentContract, CRMLead, LessonPlan, FamilyAnnouncement } from './types';

// Dados iniciais para semear o LocalStorage caso esteja vazio
const INITIAL_STUDENTS: Student[] = [
  {
    id: 'student-1',
    name: 'Arthur Silva',
    birthDate: '2021-04-12',
    parentName: 'Mariana Silva',
    phone: '(11) 98765-4321',
    whatsapp: '11987654321',
    email: 'mariana.silva@email.com',
    address: 'Alameda das Flores, 123 - Jardins, São Paulo - SP',
    modality: 'Individual',
    frequency: 2,
    monthlyFee: 480,
    enrollmentDate: '2025-02-10',
    observations: 'Adora dinâmicas de movimento e fantoches. Responde muito bem a estímulos visuais e mímicas.',
    status: 'Ativo',
    familyPin: '1234'
  },
  {
    id: 'student-2',
    name: 'Beatriz Gomes',
    birthDate: '2023-01-15',
    parentName: 'Carla Gomes',
    phone: '(11) 97775-1122',
    whatsapp: '11977751122',
    email: 'carla.gomes@email.com',
    address: 'Rua Bela Cintra, 456 - Consolação, São Paulo - SP',
    modality: 'Dupla',
    frequency: 1,
    monthlyFee: 320,
    enrollmentDate: '2025-03-05',
    observations: 'Estuda junto com o primo Lucas. É tímida nos primeiros 5 minutos, depois brinca e repete o vocabulário alegremente.',
    status: 'Ativo',
    familyPin: '5678'
  },
  {
    id: 'student-3',
    name: 'Sophia Castro',
    birthDate: '2019-09-08',
    parentName: 'Ricardo Castro',
    phone: '(11) 96655-3399',
    whatsapp: '11966553399',
    email: 'ricardo.castro@email.com',
    address: 'Av. Paulista, 1000 - Bela Vista, São Paulo - SP',
    modality: 'Pequeno Grupo',
    frequency: 2,
    monthlyFee: 280,
    enrollmentDate: '2024-08-15',
    observations: 'Desenvolvimento fluente, adora livros ilustrados de histórias sobre dinossauros em inglês.',
    status: 'Ativo',
    familyPin: '1111'
  },
  {
    id: 'student-4',
    name: 'Lucas Oliveira',
    birthDate: '2022-11-20',
    parentName: 'Tiago Oliveira',
    phone: '(11) 95544-2288',
    whatsapp: '11955442288',
    email: 'tiago.oliveira@email.com',
    address: 'Rua Bela Cintra, 456 - Consolação, São Paulo - SP',
    modality: 'Dupla',
    frequency: 1,
    monthlyFee: 320,
    enrollmentDate: '2025-03-05',
    observations: 'Estuda em dupla com a Beatriz. Gosta muito de cantar a música do alfabeto e de blocos de montar.',
    status: 'Ativo',
    familyPin: '2222'
  },
  {
    id: 'student-5',
    name: 'Melissa Rocha',
    birthDate: '2020-07-30',
    parentName: 'Renata Rocha',
    phone: '(11) 94433-8877',
    whatsapp: '11944338877',
    email: 'renata.rocha@email.com',
    address: 'Rua Augusta, 789 - Cerqueira César, São Paulo - SP',
    modality: 'Individual',
    frequency: 1,
    monthlyFee: 450,
    enrollmentDate: '2025-01-20',
    observations: 'Mãe pediu pausa temporária para viagem familiar prolongada. Retorno previsto para o próximo semestre.',
    status: 'Pausado',
    familyPin: '9999'
  }
];

const INITIAL_CLASSES: ClassSession[] = [
  {
    id: 'class-1',
    studentId: 'student-1',
    studentName: 'Arthur Silva',
    date: '2026-06-08',
    time: '14:00',
    theme: 'Farm Animals',
    vocabulary: 'Cow, Horse, Pig, Chicken, Sheep, Farm',
    notes: 'Arthur se engajou muito imitando os sons dos animais com os fantoches. Ele aprendeu rápido a cantar \"Old MacDonald had a farm\". Ótima participação!',
    status: 'Concluída',
    participation: 'Excelente',
    professor: 'Teacher Carla'
  },
  {
    id: 'class-2',
    studentId: 'student-2',
    studentName: 'Beatriz Gomes',
    date: '2026-06-09',
    time: '10:00',
    theme: 'Colors and Shapes',
    vocabulary: 'Red, Blue, Yellow, Green, Circle, Square',
    notes: 'Aula preparada com massinha de modelar colorida. Beatriz construiu círculos coloridos chamando-os pelo nome correto em inglês.',
    status: 'Agendada',
    participation: 'Boa',
    professor: 'Teacher Carla'
  },
  {
    id: 'class-3',
    studentId: 'student-4',
    studentName: 'Lucas Oliveira',
    date: '2026-06-09',
    time: '10:00',
    theme: 'Colors and Shapes',
    vocabulary: 'Red, Blue, Yellow, Green, Circle, Square',
    notes: 'Aula em dupla com Beatriz. Lucas adorou apontar para brinquedos vermelhos pela sala exclamando \"Red! Red!\".',
    status: 'Agendada',
    participation: 'Excelente',
    professor: 'Teacher Carla'
  },
  {
    id: 'class-4',
    studentId: 'student-3',
    studentName: 'Sophia Castro',
    date: '2026-06-10',
    time: '16:30',
    theme: 'Our Body parts',
    vocabulary: 'Head, Shoulders, Knees, Toes, Eyes, Ears, Mouth, Nose',
    notes: 'Simulação física e jogos corporais. Canção tradicional cantada rápida e gradualmente de ritmo lento a acelerado.',
    status: 'Agendada',
    participation: 'Excelente',
    professor: 'Teacher Carla'
  },
  {
    id: 'class-5',
    studentId: 'student-1',
    studentName: 'Arthur Silva',
    date: '2026-06-11',
    time: '14:00',
    theme: 'Fruit Salad Day',
    vocabulary: 'Apple, Banana, Orange, Grape, Strawberry',
    notes: 'Levei frutas de plástico e montamos uma feirinha lúdica no tapete da sala.',
    status: 'Agendada',
    participation: 'Boa',
    professor: 'Teacher Carla'
  },
  {
    id: 'class-6',
    studentId: 'student-2',
    studentName: 'Beatriz Gomes',
    date: '2026-06-02',
    time: '10:00',
    theme: 'Numbers 1 to 5',
    vocabulary: 'One, Two, Three, Four, Five, Blocks, Fingers',
    notes: 'Beatriz usou os blocos de areia para empilhar e contar até 5. Ótimo progresso pedagógico.',
    status: 'Concluída',
    participation: 'Excelente',
    professor: 'Teacher Carla'
  },
  {
    id: 'class-7',
    studentId: 'student-4',
    studentName: 'Lucas Oliveira',
    date: '2026-06-02',
    time: '10:00',
    theme: 'Numbers 1 to 5',
    vocabulary: 'One, Two, Three, Four, Five, Blocks, Fingers',
    notes: 'Lucas conseguiu identificar os numerais nas cartelas ilustradas com ajuda pontual.',
    status: 'Concluída',
    participation: 'Boa',
    professor: 'Teacher Carla'
  }
];

const INITIAL_PAYMENTS: MonthlyPayment[] = [
  {
    id: 'pay-1',
    studentId: 'student-1',
    studentName: 'Arthur Silva',
    dueDate: '2026-06-10',
    amount: 480,
    status: 'Pendente'
  },
  {
    id: 'pay-2',
    studentId: 'student-2',
    studentName: 'Beatriz Gomes',
    dueDate: '2026-06-05',
    amount: 320,
    status: 'Atrasado'
  },
  {
    id: 'pay-3',
    studentId: 'student-3',
    studentName: 'Sophia Castro',
    dueDate: '2026-06-12',
    amount: 280,
    status: 'Pendente'
  },
  {
    id: 'pay-4',
    studentId: 'student-4',
    studentName: 'Lucas Oliveira',
    dueDate: '2026-06-05',
    amount: 320,
    status: 'Pago',
    paymentDate: '2026-06-04'
  },
  {
    id: 'pay-5',
    studentId: 'student-5',
    studentName: 'Melissa Rocha',
    dueDate: '2026-05-10',
    amount: 450,
    status: 'Pago',
    paymentDate: '2026-05-09'
  }
];

const INITIAL_FINANCIALS: FinancialRecord[] = [
  {
    id: 'fin-1',
    type: 'Receita',
    category: 'Mensalidade',
    amount: 320,
    date: '2026-06-04',
    description: 'Mensalidade Junho/2026 - Lucas Oliveira',
    studentId: 'student-4'
  },
  {
    id: 'fin-2',
    type: 'Receita',
    category: 'Aula Experimental',
    amount: 100,
    date: '2026-06-03',
    description: 'Aula experimental avulsa realizada com Miguel Santos',
  },
  {
    id: 'fin-3',
    type: 'Despesa',
    category: 'Combustível',
    amount: 180,
    date: '2026-06-02',
    description: 'Combustível para visitas residenciais - Semana 1'
  },
  {
    id: 'fin-4',
    type: 'Despesa',
    category: 'Materiais',
    amount: 250,
    date: '2026-06-01',
    description: 'Compra de fantoches e massa de modelar premium para atividades lúdicas'
  },
  {
    id: 'fin-5',
    type: 'Despesa',
    category: 'Impressões',
    amount: 60,
    date: '2026-05-28',
    description: 'Cartões ilustrados e folhas de desenho para scrapbook'
  }
];

const INITIAL_CONTRACTS: StudentContract[] = [
  {
    id: 'contract-1',
    studentId: 'student-1',
    status: 'Assinado',
    fileName: 'contrato_prestacao_servicos_arthur_silva.pdf',
    fileSize: '1.2 MB',
    uploadedAt: '2025-02-10',
    signedAt: '2025-02-11 10:15 Uhr'
  },
  {
    id: 'contract-2',
    studentId: 'student-3',
    status: 'Pendente Assinatura',
    fileName: 'contrato_anual_pequenos_bilingues_sophia_castro.pdf',
    fileSize: '850 KB',
    uploadedAt: '2024-08-15'
  }
];

const INITIAL_LEADS: CRMLead[] = [
  {
    id: 'lead-1',
    parentName: 'Renato Mendes',
    phone: '(11) 99111-2222',
    whatsapp: '11991112222',
    childName: 'Heitor Mendes',
    childAge: '3 anos',
    status: 'Novo contato',
    notes: 'Entrou em contato pelo Instagram. Demonstrou interesse em aulas domiciliares semanais para o filho mais novo.',
    createdAt: '2026-06-01',
    history: [
      { date: '2026-06-01', note: 'Primeira conversa pelo direct do Instagram. Enviamos o folder virtual e os valores.' }
    ]
  },
  {
    id: 'lead-2',
    parentName: 'Juliana Portela',
    phone: '(11) 98888-7777',
    whatsapp: '11988887777',
    childName: 'Marina Portela',
    childAge: '4 anos',
    status: 'Aula experimental agendada',
    notes: 'Aula experimental lúdica marcada para o próximo sábado pela manhã.',
    createdAt: '2026-06-03',
    history: [
      { date: '2026-06-03', note: 'Agendou a aula lúdica para sábado, às 09:30. Enviado o guia de boas-vindas.' }
    ]
  },
  {
    id: 'lead-3',
    parentName: 'Fernando Alencar',
    phone: '(11) 97777-6666',
    whatsapp: '11977776666',
    childName: 'Enzo Alencar',
    childAge: '5 anos',
    status: 'Proposta enviada',
    notes: 'Proposta enviada para plano semestral (duas vezes na semana). Respondendo dúvidas sobre reposições.',
    createdAt: '2026-05-28',
    history: [
      { date: '2026-05-28', note: 'Chamou no WhatsApp tirando dúvidas sobre planos em grupo.' },
      { date: '2026-05-30', note: 'Proposta enviada formalmente em pdf com cronogramas e contrato.' }
    ]
  }
];

const INITIAL_PLANS: LessonPlan[] = [
  {
    id: 'plan-1',
    theme: 'Farm Animals & Sound Imitation',
    objective: 'Identificar animais da fazenda mais comuns e imitar seus sons em inglês.',
    vocabulary: 'Cow, Horse, Pig, Chicken, Sheep, Farm, Sound, Old MacDonald',
    song: 'Old MacDonald had a farm, Barnyard dance',
    story: 'Dear Zoo / Spot on the Farm',
    activity: 'Uso de fantoches de feltro + esconde-esconde no celeiro de brinquedo.',
    materialsNeeded: 'Fantoches de animais da fazenda, celebração lúdica com celeiro de papelão, livro Spot on the farm.',
    isTemplate: true
  },
  {
    id: 'plan-2',
    theme: 'Exploration of Fruit Colors',
    objective: 'Distinguir cores no contexto lúdico de frutas e vegetais comuns.',
    vocabulary: 'Apple, Banana, Orange, Grapes, Strawberry, Red, Yellow, Orange, Purple',
    song: 'The Fruit Song, Apples and Bananas',
    story: 'The Very Hungry Caterpillar',
    activity: 'Massinha de modelar criando pequenos pratos com as respectivas frutas.',
    materialsNeeded: 'Livro da Lagarta Comilona, massinhas coloridas, pratinhos de plástico.',
    isTemplate: true
  },
  {
    id: 'plan-3',
    theme: 'My Body Parts & Simon Says',
    objective: 'Nomear partes do rosto e corpo realizando mímica corporal ativa.',
    vocabulary: 'Head, Shoulders, Knees, Toes, Eyes, Ears, Mouth, Nose',
    song: 'Head, Shoulders, Knees and Toes melody, Shake your body',
    story: 'Go Away, Big Green Monster!',
    activity: 'Jogo Simon Says apontando e se movimentando; colagem das partes do rosto no scrapbook.',
    materialsNeeded: 'Impressos de partes do rosto, tesoura infantil sem ponta, cola bastão, folhas coloridas.',
    isTemplate: true
  }
];

const INITIAL_ANNOUNCEMENTS: FamilyAnnouncement[] = [
  {
    id: 'ann-1',
    title: 'Recital Lúdico de Fim de Semestre',
    content: 'Queridas famílias! No dia 27 de Junho teremos o nosso encontro especial onde as crianças irão cantar algumas de nossas canções favoritas juntos. Preparem as câmeras!',
    date: '2026-06-05',
    author: 'Teacher Carla Cristina'
  },
  {
    id: 'ann-2',
    title: 'Novos Jogos de Tabuleiro Gigante',
    content: 'Olá! Adquirimos novos materiais pedagógicos temáticos (tabuleiros gigantes no tapete para pular em inglês). Eles serão introduzidos nas aulas desta semana!',
    date: '2026-06-07',
    author: 'Teacher Carla Cristina'
  }
];

// Helper functions para ler/escrever no LocalStorage
export function initializeStorage() {
  if (!localStorage.getItem('pb_students')) {
    localStorage.setItem('pb_students', JSON.stringify(INITIAL_STUDENTS));
  }
  if (!localStorage.getItem('pb_classes')) {
    localStorage.setItem('pb_classes', JSON.stringify(INITIAL_CLASSES));
  }
  if (!localStorage.getItem('pb_payments')) {
    localStorage.setItem('pb_payments', JSON.stringify(INITIAL_PAYMENTS));
  }
  if (!localStorage.getItem('pb_financials')) {
    localStorage.setItem('pb_financials', JSON.stringify(INITIAL_FINANCIALS));
  }
  if (!localStorage.getItem('pb_contracts')) {
    localStorage.setItem('pb_contracts', JSON.stringify(INITIAL_CONTRACTS));
  }
  if (!localStorage.getItem('pb_leads')) {
    localStorage.setItem('pb_leads', JSON.stringify(INITIAL_LEADS));
  }
  if (!localStorage.getItem('pb_plans')) {
    localStorage.setItem('pb_plans', JSON.stringify(INITIAL_PLANS));
  }
  if (!localStorage.getItem('pb_announcements')) {
    localStorage.setItem('pb_announcements', JSON.stringify(INITIAL_ANNOUNCEMENTS));
  }
}

export function getStudents(): Student[] {
  initializeStorage();
  return JSON.parse(localStorage.getItem('pb_students') || '[]');
}

export function saveStudents(students: Student[]) {
  localStorage.setItem('pb_students', JSON.stringify(students));
}

export function getClasses(): ClassSession[] {
  initializeStorage();
  return JSON.parse(localStorage.getItem('pb_classes') || '[]');
}

export function saveClasses(classes: ClassSession[]) {
  localStorage.setItem('pb_classes', JSON.stringify(classes));
}

export function getPayments(): MonthlyPayment[] {
  initializeStorage();
  return JSON.parse(localStorage.getItem('pb_payments') || '[]');
}

export function savePayments(payments: MonthlyPayment[]) {
  localStorage.setItem('pb_payments', JSON.stringify(payments));
}

export function getFinancials(): FinancialRecord[] {
  initializeStorage();
  return JSON.parse(localStorage.getItem('pb_financials') || '[]');
}

export function saveFinancials(financialRecords: FinancialRecord[]) {
  localStorage.setItem('pb_financials', JSON.stringify(financialRecords));
}

export function getContracts(): StudentContract[] {
  initializeStorage();
  return JSON.parse(localStorage.getItem('pb_contracts') || '[]');
}

export function saveContracts(contracts: StudentContract[]) {
  localStorage.setItem('pb_contracts', JSON.stringify(contracts));
}

export function getLeads(): CRMLead[] {
  initializeStorage();
  return JSON.parse(localStorage.getItem('pb_leads') || '[]');
}

export function saveLeads(leads: CRMLead[]) {
  localStorage.setItem('pb_leads', JSON.stringify(leads));
}

export function getPlans(): LessonPlan[] {
  initializeStorage();
  return JSON.parse(localStorage.getItem('pb_plans') || '[]');
}

export function savePlans(plans: LessonPlan[]) {
  localStorage.setItem('pb_plans', JSON.stringify(plans));
}

export function getAnnouncements(): FamilyAnnouncement[] {
  initializeStorage();
  return JSON.parse(localStorage.getItem('pb_announcements') || '[]');
}

export function saveAnnouncements(announcements: FamilyAnnouncement[]) {
  localStorage.setItem('pb_announcements', JSON.stringify(announcements));
}

export function resetToDefaults() {
  localStorage.setItem('pb_students', JSON.stringify(INITIAL_STUDENTS));
  localStorage.setItem('pb_classes', JSON.stringify(INITIAL_CLASSES));
  localStorage.setItem('pb_payments', JSON.stringify(INITIAL_PAYMENTS));
  localStorage.setItem('pb_financials', JSON.stringify(INITIAL_FINANCIALS));
  localStorage.setItem('pb_contracts', JSON.stringify(INITIAL_CONTRACTS));
  localStorage.setItem('pb_leads', JSON.stringify(INITIAL_LEADS));
  localStorage.setItem('pb_plans', JSON.stringify(INITIAL_PLANS));
  localStorage.setItem('pb_announcements', JSON.stringify(INITIAL_ANNOUNCEMENTS));
  window.location.reload();
}
